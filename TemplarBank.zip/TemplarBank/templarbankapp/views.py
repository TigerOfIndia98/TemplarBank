
from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import UserRegistrationForm,BankAccountForm
from .models import BankAccount, CarouselImage, NewsHeadline
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm

import random

def index(request):
    return render(request, 'templarbank.html')

def homepage(request):
    data = CarouselImage.objects.all()
    headlines = NewsHeadline.objects.all()
    return render(request, 'templarbank.html', {'data': data, 'headlines': headlines})

def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user_form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('create_account')
    else:
        user_form = UserRegistrationForm()
    return render(request, 'register.html', {'form': user_form})

def dashboard(request):
    if not request.user.is_authenticated:
        return redirect('login')

    try:
        account = BankAccount.objects.get(user=request.user)
    except BankAccount.DoesNotExist:
        account = None

    return render(request, 'dashboard.html', {'account': account})

def create_account(request):
    if request.method == 'POST':
        account_number = ''.join([str(random.randint(0, 9)) for _ in range(9)])
        account = BankAccount.objects.create(
            user=request.user,
            account_number=account_number,
            balance=0.0
        )
        return redirect('dashboard')
    return render(request, 'create_account.html')

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)  # Bind POST data to the form
        if form.is_valid():  # Validate the form
            user = form.get_user()  # Get the authenticated user
            login(request, user)  # Log the user in
            return redirect('dashboard')  # Redirect to the dashboard
    else:
        form = AuthenticationForm()  # Render an empty form for GET requests
    return render(request, 'login.html', {'form': form})


def loan_emi_calculator(request):
    emi = None
    if request.method == 'POST':
        principal = float(request.POST.get('principal', 0))
        rate_of_interest = float(request.POST.get('rate_of_interest', 0)) / 12 / 100
        tenure = int(request.POST.get('tenure', 0))

        if principal > 0 and rate_of_interest > 0 and tenure > 0:
            emi = (principal * rate_of_interest * (1 + rate_of_interest)**tenure) / ((1 + rate_of_interest)**tenure - 1)

    return render(request, 'loan_emi_calculator.html', {'emi': emi})
