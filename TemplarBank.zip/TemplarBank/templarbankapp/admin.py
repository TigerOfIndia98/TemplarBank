# templarbankapp/admin.py
# templarbankapp/admin.py

# templarbankapp/admin.py

from django.contrib import admin
from .models import CarouselImage
from .models import NewsHeadline

admin.site.register(CarouselImage)
admin.site.register(NewsHeadline)