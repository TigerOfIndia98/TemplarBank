# TemplarBank/urls.py
# templarbankapp/urls.py
from django.contrib.auth.views import LogoutView
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from django.views.generic import RedirectView
from .views import login_view

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('login/', login_view, name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
    path('register/', views.register, name='register'),
    path('accounts/profile/', RedirectView.as_view(url='/dashboard/')),  # Redirect to dashboard
    path('create-account/', views.create_account, name='create_account'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('loan-emi-calculator/', views.loan_emi_calculator, name='loan_emi_calculator'),
]

